Coloris({
 	theme: 'pill',
  	themeMode: 'auto'
});
